function verify(){
    if(document.getElementById("nickname").value == ""){
        alert("Insira uma nickname")
    }else{
        enviarNome();
        window.location='./jogo.html';
    }
}

function enviarNome(){
    localStorage.setItem('nickname', JSON.stringify(document.getElementById("nickname").value)); 
}

