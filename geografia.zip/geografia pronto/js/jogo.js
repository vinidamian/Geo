(function() {
  //Array que armazenará os objetos com src e id de 1 a 8
  var images = [];

  //Imagem a ser exibida em caso de acerto
  var matchSign = document.querySelector("#match");

  //Imagem de fim do jogo
  var modal = document.querySelector("#gameOver");

  //Array que armazena as cartas viradas
  var flippedCards = [];

  //Variável contadora de acertos. ao chegar em 8 o jogo termina
  var matches = 0;

  //Estrutura de atribiução das imagens aos card
  for (var i = 0; i < 16; i++) {
    //Cria um objeto img com um src e um id
    var img = {
      src: "img/" + i + ".png",
      id: i % 8
    };

    //Inserer o objeto criado no array
    images.push(img);
  }

  //Chama a função de inicialização do jogo
  startGame();

  //Função de inicialização do jogo
  function startGame() {
    //Zera o array de cartas viradas
    flippedCards = [];

    //Zera o contador de acertos
    matches = 0;

    //Embaralhamento do array de imagens
    images = randomSort(images);

    //Lista de elementos div com as classes back e front
    var backFaces = document.getElementsByClassName("back");
    var frontFaces = document.getElementsByClassName("front");

    //Posicionamento das cartas e adição do evento click
    for (var i = 0; i < 16; i++) {
      //Limpa as cartas marcadas
      backFaces[i].classList.remove("match", "flipped");
      frontFaces[i].classList.remove("match", "flipped");

      //Posiciona as cartas no tabuleiro
      var card = document.querySelector("#card" + i);
      card.style.left = i % 8 === 0 ? 5 + "px" : 5 + (i % 8) * 165 + "px";
      card.style.top = i / 8 >= 1 ? 250 + "px" : 5 + "px";

      //Adiciona às cartas o evento click chamando a função que vira as cartas
      card.addEventListener("click", flipCard, false);

      //Adiciona as imagens às cartas
      frontFaces[i].style.background = "url('" + images[i].src + "')";
      frontFaces[i].setAttribute("id", images[i].id);
    }

    //Joga a imagem de game over para o plano de fundo
    modal.style.zIndex = "-2";

    //Remove o evento click da imagem de game over
    modal.removeEventListener(
      "click",
      function() {
        startGame();
      },
      false
    );
  } //Fim da função de inicialização do jogo

  //Função que vira as cartas
  function flipCard() {
    //Verifica se o número de cartas viradas é menor que 2
    if (flippedCards.length < 2) {
      //Pega as faces da carta clicada
      var faces = this.getElementsByClassName("face");

      //Confere se a carta já está virada, impedindo que a mesma carta seja virada duas vezes
      if (faces[0].classList[2]) {
        return;
      }

      //Adiciona a classe fliped às faces da carta para que sejam viradas
      faces[0].classList.toggle("flipped");
      faces[1].classList.toggle("flipped");

      //Adiciona a carta clicada ao array de cartas viradas
      flippedCards.push(this);

      //Verifica se o número de cartas no array de cartas viradas é igual a 2
      if (flippedCards.length === 2) {
        //Compara o id das cartas viradas para ver se houve um acerto
        if (
          flippedCards[0].childNodes[3].id === flippedCards[1].childNodes[3].id
        ) {
          //Em caso de acerto adiciona a classe match a todas as faces das duas cartas presentes no array de cartas viradas
          flippedCards[0].childNodes[1].classList.toggle("match");
          flippedCards[0].childNodes[3].classList.toggle("match");
          flippedCards[1].childNodes[1].classList.toggle("match");
          flippedCards[1].childNodes[3].classList.toggle("match");

          //Chama a função que exibe a mensagem MATCH
          matchCardsSign();

          //Limpa o array de cartas viradas
          flippedCards = [];

          //Soma um ao contador de acertos
          matches++;

          //Verifica se o contador de acertos chegou a 8
          if (matches >= 8) {
            //Caso haja 8 acertos, chama a função que finaliza o jogo
            gameOver();
          }
        }
      }
    } else {
      //Em caso haver duas cartas no array de cartas viradas (terceiro click) remove a classe flipped das cartas no array de cartas viradas
      flippedCards[0].childNodes[1].classList.toggle("flipped");
      flippedCards[0].childNodes[3].classList.toggle("flipped");
      flippedCards[1].childNodes[1].classList.toggle("flipped");
      flippedCards[1].childNodes[3].classList.toggle("flipped");

      //Limpa o array de cartas viradas
      flippedCards = [];
    }
  }

  //Função que embaralha as cartas recebendo um array de cartas por parâmetro
  function randomSort(array) {
    //Cria um array vazio
    var newArray = [];

    //Executa a estrutura enquanto o novo array não atingir o mesmo número de elementos do arrau passado por parâmetro
    while (newArray.length !== array.length) {
      //Cria uma variável i recebendo um número aleatório entre 0 e o número de elementos no array -1
      var i = Math.floor(Math.random() * array.length);

      //Verifica se o elemento indicado pelo índice i já existe no array novo
      if (newArray.indexOf(array[i]) < 0) {
        //Caso não exista é inserido
        newArray.push(array[i]);
      }
    }

    //Retorna o array novo, que possui os elementos do array passado por parâmetro embaralhados
    return newArray;
  } //Fim da função que embaralha as cartas

  //Função que gera o sinal de MATCH
  function matchCardsSign() {
    //Joga a mensagem de MATCH para o primeiro plano
    matchSign.style.zIndex = "1";

    //Deixa a mensagem transparente
    matchSign.style.opacity = "0";

    //Move a mensagem para cima
    matchSign.style.top = "150px";

    //Função executada após 1.5 segundo
    setTimeout(function() {
      //Joga a mensagem de MATCH para o plano de fundo
      matchSign.style.zIndex = "-1";

      //Remove a transparência da mansagem
      matchSign.style.opacity = "1";

      //Move a mensagem para o centro da tela
      matchSign.style.top = "250px";
    }, 1500);
  } //Fim da função que exibe mensagem de MATCH

  //Função de fim do jogo
  function gameOver() {
    //Joga a mensagem de fim do jogo para o plano da frente
    modal.style.zIndex = "99";

    //Adiciona o evento click à imagem de game over
    modal.addEventListener(
      "click",
      function() {
        //Chama a função que reinicia o jogo
        startGame();
      },
      false
    );
  }
})();

//Ao fazer o carregamento da página chama-se a fução "mostrarNome"
window.onload = mostrarNome()

//Retorna a referência do elemento através do seu ID (pnickname) desabilitando o mesmo
document.getElementById("pnickname").disabled = true;

//Mostra o nickname do jogador
function mostrarNome() {
  //Retorna o nickname do jogador ao no input
  document.getElementById("pnickname").value = JSON.parse(localStorage.getItem("nickname")
  );
}
