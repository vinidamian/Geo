//Verifica se há algum nickname dentro do input para o jogo ser iniciado
function verify(){
    //Condicional que verifica se tem ou não valor dentro do input
    if(document.getElementById("nickname").value == ""){
        //Manda um pop-up na tela
        alert("Insira uma nickname")
    }else /*Executa caso tenha valor no input*/{
        //Chama a função que salva o nickname do jogador
        enviarNome();
        //Muda a página para a do jogo
        window.location='./jogo.html';
    }
}

//Salva o nickname do jogador
function enviarNome(){
    //O nickname do jogardor é salvo por meio do JSON no LocalStorage
    localStorage.setItem('nickname', JSON.stringify(document.getElementById("nickname").value)); 
}

